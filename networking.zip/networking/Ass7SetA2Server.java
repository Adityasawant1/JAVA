import java.net.*;
import java.io.*;
class Ass7SetA2Server
{
    public static void main(String args[]) throws UnknownHostException, IOException
    {
        ServerSocket ss=new ServerSocket (5000);
        System.out.println ("Server started, waiting for file to search-");

        Socket s=ss.accept (); 
        System.out.println ("Client connected");

        // Reading file name from client side.
        InputStream is=s.getInputStream();
        DataInputStream dis=new DataInputStream(is);

        OutputStream os=s.getOutputStream();
        DataOutputStream dos=new DataOutputStream(os);

        String fn=dis.readUTF();
        File f1=new File(fn);
        String msg="";        int c;

        // Checking for file existence.
        if (f1.exists())
        {
            System.out.println ("File Exists");

            FileInputStream fis=new FileInputStream(f1);
            msg="File contents are : \n";
            while ((c=fis.read ())!=-1)
                msg=msg+(char)c;
            dos.writeUTF(msg);
            fis.close ();
        }
        else
            dos.writeUTF("File NOT Found");

        dis.close();
        dos.close();
        s.close();
    }
}