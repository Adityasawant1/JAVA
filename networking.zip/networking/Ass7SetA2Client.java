import java.net.*;
import java.util.Scanner;
import java.io.*;

class Ass7SetA2Client {
    public static void main(String args[]) throws UnknownHostException, IOException {
        Socket s = new Socket("localhost", 5000);

        // BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        Scanner sc = new Scanner(System.in);

        OutputStream os = s.getOutputStream();
        DataOutputStream dos = new DataOutputStream(os);

        InputStream is = s.getInputStream();
        DataInputStream dis = new DataInputStream(is);

        System.out.println("Enter file name to search");
        String fn = sc.next();
        dos.writeUTF(fn);
        // reading the server response
        String msg = dis.readUTF();
        System.out.println(msg);
    }
}