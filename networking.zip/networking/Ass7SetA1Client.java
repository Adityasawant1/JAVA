import java.net.*;
import java.io.*;
import java.util.* ;

class Ass7SetA1Client
{
    public static void main(String args[]) throws UnknownHostException, IOException
    {
        Socket s=new Socket("localhost",1000);

        InputStream is=s.getInputStream();
        DataInputStream dis=new DataInputStream(is);

        String str = dis.readUTF();
        System.out.println(str);
    }
}