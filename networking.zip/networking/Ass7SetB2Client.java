import java.net.*;
import java.io.*;
import java.util.*;

class Ass7SetB2Client {
    public static void main(String args[]) throws UnknownHostException, IOException {
        Socket s = new Socket("localhost", 1000);

        // BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        Scanner sc = new Scanner(System.in);

        OutputStream os = s.getOutputStream();
        DataOutputStream dos = new DataOutputStream(os);

        System.out.println("Enter messages, type END to stop");

        while (true) {
            System.out.print("Client Side = ");
            String s1 = sc.next();

            dos.writeUTF(s1);
            if (s1.equals("end") || s1.equals("END")) {
                System.out.println("Chatting terminated");
                break;
            }
        }
    }
}