import java.net.*;
import java.io.*;
import java.util.*;

class Ass7SetB1Server
{
    public static void main(String args[]) throws UnknownHostException, IOException
    {
        String fn,msg="";
        File f1;
        int c;

        ServerSocket ss=new ServerSocket (5000);
        System.out.println ("Server started, waiting for file to search-");

        Socket s=ss.accept ();
        System.out.println ("Client connected");

        // Reading file name from client side.
        InputStream is=s.getInputStream(); 
        DataInputStream dis=new DataInputStream(is);

        OutputStream os=s.getOutputStream();
        DataOutputStream dos=new DataOutputStream(os);

        ArrayList al = new ArrayList();

        while (true)
        {
            fn=dis.readUTF();
            if (fn.equals("END") || fn.equals("end"))
                break;
            else
			{
                al.add(fn);
				System.out.println("File Name received : " + fn);
			}
        }

        for (int i=0;i<al.size();i++)
        {
            f1=new File(al.get(i).toString());
            if (f1.exists())
                dos.writeUTF(al.get(i).toString() + " is exist.");
            else
                dos.writeUTF(al.get(i).toString() + " NOT is exist.");
        }

        dis.close();
        dos.close();
        s.close();
    }
}