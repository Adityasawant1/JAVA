// UTF = Unicode Transformation Format

import java.net.*;
import java.io.*;
import java.util.* ;

class Ass7SetB2Server
{
    public static void main(String args[])
    throws UnknownHostException, IOException
    {
        ServerSocket ss=new ServerSocket(1000);
        System.out.println("Server started, waiting for client-");
        String str;

        Socket s = ss.accept();
        System.out.println("Client connected");
        System.out.println("Receiving Messages = ");

        InputStream is = s.getInputStream();
        DataInputStream dis=new DataInputStream(is);

        while (true) 
        {
            // reading from client side.
            str = dis.readUTF();

            if (str.equals("end")||str.equals("END"))
            {
                System.out.println("Chatting terminated");
                break;
            }
			else
                System.out.println(str);
				
        }//end while
    }
}