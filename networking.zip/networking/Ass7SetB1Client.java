import java.net.*;
import java.util.Scanner;
import java.io.*;

class Ass7SetB1Client {
    public static void main(String args[]) throws UnknownHostException, IOException {
        try {
            Socket s = new Socket("localhost", 5000);

            // BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
            Scanner sc = new Scanner(System.in);

            OutputStream os = s.getOutputStream();
            DataOutputStream dos = new DataOutputStream(os);

            InputStream is = s.getInputStream();
            DataInputStream dis = new DataInputStream(is);

            while (true) {
                System.out.println("Enter file name to search : ");
                String fn = sc.next();
                dos.writeUTF(fn);
                if (fn.equals("END") || fn.equals("end"))
                    break;
            }
            System.out.println("\n\n Result from Server : ");
            while (true) {
                String msg = dis.readUTF();
                System.out.println(msg);
            }
        } catch (Exception e) {
        }
    }
}