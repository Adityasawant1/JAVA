// UTF = Unicode Transformation Format
import java.net.*;
import java.io.*;
import java.util.* ;

public class Ass7SetA1Server
{
    public static void main(String args[]) throws UnknownHostException, IOException
    {
        ServerSocket ss=new ServerSocket(1000);
        System.out.println("Server started, waiting for client-");
        String str;

        Socket s = ss.accept();
        System.out.println("Client connected");

        OutputStream os = s.getOutputStream();
        DataOutputStream dos=new DataOutputStream(os);

        dos.writeUTF("Server Date = "+ new Date());
    }
}